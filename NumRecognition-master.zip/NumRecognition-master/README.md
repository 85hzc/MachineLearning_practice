# NumRecognition
利用神经网络识别手写数字，MNIST数据集测试


更多相信信息：https://blog.csdn.net/qq_28869927/article/details/83281190
