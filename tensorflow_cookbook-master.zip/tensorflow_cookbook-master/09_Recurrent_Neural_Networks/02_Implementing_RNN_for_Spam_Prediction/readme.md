# Implementing an RNN for Spam Prediction

Placeholder for future purposes
