# Parallelizing TensorFlow

Placeholder for future purposes
